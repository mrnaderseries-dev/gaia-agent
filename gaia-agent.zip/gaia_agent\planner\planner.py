
from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

from gaia_agent.agents.answer_sanitizer import AnswerSanitizer
from gaia_agent.agents.verifier import (
    VerificationInput,
    VerifierAgent,
)

from gaia_agent.context.ContextBuilder import ContextBuilder

from gaia_agent.core.agent_execution import AgentExecution
from gaia_agent.core.agent_state import AgentState

from gaia_agent.planner.planner import Planner
from gaia_agent.planner.plan_schema import (
    PlanSchema,
    PlanStep,
    StepType,
)

from gaia_agent.reliability.engine import ReliabilityEngine
from gaia_agent.reliability.error_handler import ErrorHandler
from gaia_agent.reliability.errors import AgentError
from gaia_agent.reliability.loop_detection import LoopDetector

from gaia_agent.observability.events import (
    EventType,
    create_event,
)
from gaia_agent.observability.logger import EventLogger
from gaia_agent.observability.metrics import Metrics
from gaia_agent.observability.tracer import Tracer


class Orchestrator:
    """
    Coordinates the agent execution workflow.

    Responsibilities
    ----------------
    - build execution context
    - create the initial plan
    - select the current plan step
    - coordinate step replanning after recovery
    - validate planning results
    - detect execution loops
    - prepare AgentState for AgentExecution
    - delegate execution to AgentExecution
    - delegate reliability decisions to ReliabilityEngine
    - coordinate final-answer generation
    - coordinate final-answer verification
    - sanitize the verified answer
    - emit workflow-level observability

    Does NOT
    --------
    - execute tools directly
    - execute LLM calls directly
    - implement retry
    - implement recovery policy
    - classify failures
    - evaluate retry policy
    - evaluate recovery policy
    - evaluate risk
    - evaluate approval
    - execute human approval
    - track individual LLM tokens
    - track individual tool latency
    """

    def __init__(
        self,
        *,
        context_builder: ContextBuilder,
        planner: Planner,
        agent_execution: AgentExecution,
        error_handler: ErrorHandler,
        reliability_engine: ReliabilityEngine,
        loop_detector: LoopDetector,
        verifier: VerifierAgent,
        answer_sanitizer: AnswerSanitizer,
        event_logger: EventLogger,
        metrics: Metrics,
        tracer: Tracer,
    ) -> None:

        self.context_builder = context_builder
        self.planner = planner
        self.agent_execution = agent_execution

        self.error_handler = error_handler
        self.reliability_engine = reliability_engine
        self.loop_detector = loop_detector

        self.verifier = verifier
        self.answer_sanitizer = answer_sanitizer

        self.event_logger = event_logger
        self.metrics = metrics
        self.tracer = tracer

        self.state: AgentState | None = None

        self.correlation_id: UUID = uuid4()

  
    def bind_state(
        self,
        state: AgentState,
    ) -> None:

        self.state = state

        self.agent_execution.bind_state(
            state
        )

    def _require_state(
        self,
    ) -> AgentState:

        if self.state is None:
            raise RuntimeError(
                "AgentState is not bound. "
                "Call bind_state() before execution."
            )

        return self.state

    async def run_iteration(
        self,
    ) -> None:

        state = self._require_state()

        span = self.tracer.start_span(
            operation="orchestrator.iteration",
            correlation_id=self.correlation_id,
        )

        try:


            context = await self.context_builder.build(
                state
            )

            self.metrics.increment(
                "context_builds"
            )

          
            if not state.plan:

                planning_success = await self._create_plan(
                    context.items
                )

                if not planning_success:
                    return

            if state.current_step >= len(state.plan):

                await self._handle_plan_completion()

                return


            step = state.plan[
                state.current_step
            ]

           

            loop_result = self.loop_detector.check(
                action=step.action,
                tool_name=step.tool_name,
                arguments=step.arguments,
            )

            if loop_result.detected:

                await self._handle_loop(
                    loop_result.message
                )

                return

           
            self._prepare_step(
                step
            )

         
            result = await self.reliability_engine.execute(
                operation=self.agent_execution.execute,
                operation_name="agent_execution",
                source="orchestrator",
                validator=self._validate_execution_result,
                recovery_operation=self._recover_execution,
            )

            if not result.success:

                state.tool_error = result.reason

                self.metrics.increment(
                    "agent_execution_failures"
                )

                self._emit_agent_failure(
                    result.reason,
                    error=result.error,
                )

                return

            if state.blocked:

                self.metrics.increment(
                    "execution_blocked"
                )

                return

       

            self._capture_step_result(
                step
            )

            

            self._mark_step_completed(
                step
            )

        except Exception as exc:

            error = self.error_handler.handle(
                exc,
                source="orchestrator",
                operation="run_iteration",
            )

            state.tool_error = error.message

            self.metrics.increment(
                "agent_errors"
            )

            self._emit_agent_failure(
                error.message,
                error=error,
            )

        finally:

            self.tracer.end_span(
                span,
                error=(
                    state.tool_error
                    if state.tool_error
                    else None
                ),
            )

  
    async def _create_plan(
        self,
        context: list[Any],
    ) -> bool:

        state = self._require_state()

        result = await self.reliability_engine.execute(
            operation=lambda: self._generate_plan(
                
                context
            ),
            operation_name="generate_plan",
            source="planner",
            validator=self._validate_plan_result,
        )

        if not result.success:

            state.tool_error = result.reason

            self.metrics.increment(
                "planning_failures"
            )

            self._emit_agent_failure(
                result.reason,
                error=result.error,
            )

            return False

        plan = result.result

        if not isinstance(
            plan,
            PlanSchema,
        ):

            error = self.error_handler.handle(
                TypeError(
                    "Planner returned an invalid result type."
                ),
                source="planner",
                operation="generate_plan",
            )

            state.tool_error = error.message

            self.metrics.increment(
                "planning_failures"
            )

            self._emit_agent_failure(
                error.message,
                error=error,
            )

            return False

        state.plan = list(
            plan.steps
        )

        state.current_step = 0

        state.completed_steps.clear()

        state.tool_result = None
        state.tool_error = None

        self.metrics.increment(
            "plans_created"
        )

        return True

    async def _generate_plan(
        self,
        context: list[Any],
    ) -> PlanSchema:

        state = self._require_state()

        return await self.planner.generate_plan(
            user_question=state.user_request,
            context=context,
        )

    def _validate_plan_result(
        self,
        plan: Any,
    ) -> bool:

        if not isinstance(
            plan,
            PlanSchema,
        ):
            return False

        try:

            self.planner._validate_plan(
                plan
            )

        except (ValueError, TypeError):

            return False

        loop_result = self.loop_detector.check_plan(
            plan.steps
        )

        return not loop_result.detected

   
    async def _recover_execution(
        self,
        error: AgentError,
    ) -> Any:

        state = self._require_state()

        if state.current_step >= len(state.plan):

            raise ValueError(
                "Cannot replan because the current step "
                "is outside the current plan."
            )

        failed_step = state.plan[
            state.current_step
        ]

        context = await self.context_builder.build(
            state
        )

        new_step = await self.planner.replan_step(
            user_question=state.user_request,
            context=context.items,
            failed_step=failed_step,
            failure=error,
        )
        

        self._validate_replanned_step(
            new_step
        )

        self._replace_failed_step(
            new_step
        )
        self._prepare_step(new_step)

        self.metrics.increment(
            "step_replans"
        )

        return new_step

    def _validate_replanned_step(
        self,
        step: PlanStep,
    ) -> None:

        if not isinstance(
            step,
            PlanStep,
        ):
            raise TypeError(
                "Planner returned an invalid replacement step."
            )

        try:

            self.planner._validate_step(
                step
            )
            

        except (ValueError, TypeError) as exc:

            raise ValueError(
                "Planner produced an invalid replacement step."
            ) from exc

        loop_result = self.loop_detector.check(
            action=step.action,
            tool_name=step.tool_name,
            arguments=step.arguments,
        )

        if loop_result.detected:

            raise ValueError(
                "Planner produced a replacement step "
                "that would repeat a detected loop."
            )

    def _replace_failed_step(
        self,
        new_step: PlanStep,
    ) -> None:

        state = self._require_state()

        current_index = state.current_step

        state.plan[current_index] = PlanStep(
            step_id=current_index,
            action=new_step.action,
            step_type=new_step.step_type,
            tool_name=new_step.tool_name,
            arguments=dict(
                new_step.arguments or {}
            ),
        )

        state.tool_result = None
        state.tool_error = None
        state.blocked = False

        state.execution_decision = None
        state.approval_decision = None
        state.risk_assessment = None

    def _prepare_step(
        self,
        step: PlanStep,
    ) -> None:

        state = self._require_state()

        state.current_action = step.action

        state.step_type = step.step_type

        state.tool_name = step.tool_name

        state.tool_arguments = dict(
            step.arguments or {}
        )

        state.tool_result = None
        state.tool_error = None

        state.blocked = False

        state.execution_decision = None
        state.approval_decision = None
        state.risk_assessment = None

    # ------------------------------------------------------------------
    # EXECUTION RESULT
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_execution_result(
        state: AgentState,
    ) -> bool:

        if state.blocked:
            return True

        if state.tool_error is not None:
            return False

        return True

    # ------------------------------------------------------------------
    # STEP RESULT
    # ------------------------------------------------------------------

    def _capture_step_result(
        self,
        step: PlanStep,
    ) -> None:

        state = self._require_state()

        if step.step_type != StepType.LLM:
            return

        if not getattr(
            step,
            "is_final_answer",
            False,
        ):
            return

        if state.tool_result is None:

            raise ValueError(
                "Final answer generation returned no result."
            )

        state.final_answer = (
            self._normalize_answer(
                state.tool_result
            )
        )

        state.final_answer_ready = True

    @staticmethod
    def _normalize_answer(
        result: Any,
    ) -> str:

        if isinstance(
            result,
            str,
        ):
            return result

        if result is None:

            raise ValueError(
                "LLM returned no final answer."
            )

        if hasattr(
            result,
            "model_dump_json",
        ):

            return result.model_dump_json()

        return str(
            result
        )

    def _mark_step_completed(
        self,
        step: PlanStep,
    ) -> None:

        state = self._require_state()

        if state.current_step not in state.completed_steps:

            state.completed_steps.append(
                state.current_step
            )

        state.current_step += 1

        state.retry_count = 0
        state.recovery_attempted = False

        self.metrics.increment(
            "steps_completed"
        )

    # ------------------------------------------------------------------
    # PLAN COMPLETION
    # ------------------------------------------------------------------

    async def _handle_plan_completion(
        self,
    ) -> None:

        state = self._require_state()

        if not state.final_answer_ready:

            await self._create_final_answer_step()

            return

        if not state.final_answer_verified:

            await self._verify_final_answer()

    async def _create_final_answer_step(
        self,
    ) -> None:

        state = self._require_state()

        step_id = len(
            state.plan
        )

        state.plan.append(
            PlanStep(
                step_id=step_id,
                action=(
                    "Generate final answer "
                    "from gathered results."
                ),
                step_type=StepType.LLM,
                tool_name=None,
                arguments={},
                is_final_answer=True,
            )
        )

        self.metrics.increment(
            "final_answer_generation_steps"
        )

    # ------------------------------------------------------------------
    # FINAL ANSWER VERIFICATION
    # ------------------------------------------------------------------

    async def _verify_final_answer(
        self,
    ) -> None:

        state = self._require_state()

        if state.final_answer is None:

            error = self.error_handler.handle(
                ValueError(
                    "Final answer is missing."
                ),
                source="orchestrator",
                operation="verify_answer",
            )

            state.tool_error = error.message

            self.metrics.increment(
                "verification_failures"
            )

            self._emit_agent_failure(
                error.message,
                error=error,
            )

            return

        context = await self.context_builder.build(
            state
        )

        self.metrics.increment(
            "verification_context_builds"
        )

        verification_input = VerificationInput(
            question=state.user_request,
            candidate_answer=state.final_answer,
            raw_data=context.items,
        )

        result = await self.reliability_engine.execute(
            operation=lambda: self.verifier.verify(
                verification_input
            ),
            operation_name="verify_answer",
            source="verifier",
            validator=self._validate_verification_result,
        )

        if not result.success:

            state.tool_error = result.reason

            self.metrics.increment(
                "verification_failures"
            )

            self._emit_agent_failure(
                result.reason,
                error=result.error,
            )

            return

        verification = result.result

        if verification is None:

            state.tool_error = (
                "Verifier returned no result."
            )

            self.metrics.increment(
                "verification_failures"
            )

            return

        if not verification.verified:

            error = AgentError(
                error_type="AnswerVerificationError",
                message=verification.reason,
                source="verifier",
                operation="verify_answer",
                recoverable=True,
            )

            failure_result = (
                await self.reliability_engine.handle_failure(
                    error=error,
                    operation_name="answer_verification",
                    recovery_operation=self._recover_verification,
                )
            )

            if not failure_result.success:

                state.tool_error = (
                    failure_result.reason
                )

                self.metrics.increment(
                    "verification_failures"
                )

                self._emit_agent_failure(
                    failure_result.reason,
                    error=failure_result.error,
                )

            return

        state.final_answer = (
            self.answer_sanitizer.sanitize(
                verification.answer
            )
        )

        state.final_answer_ready = True
        state.final_answer_verified = True

        self.metrics.increment(
            "answers_verified"
        )

    @staticmethod
    def _validate_verification_result(
        result: Any,
    ) -> bool:

        return result is not None

    async def _recover_verification(
        self,
        error: AgentError,
    ) -> Any:

        state = self._require_state()

        context = await self.context_builder.build(
            state
        )

        if state.current_step >= len(state.plan):

            raise ValueError(
                "Cannot recover verification because "
                "no current plan step exists."
            )

        failed_step = state.plan[
            state.current_step
        ]

        new_step = await self.planner.replan_step(
            user_question=state.user_request,
            context=context.items,
            failed_step=failed_step,
            failure=error,
        )

        self._validate_replanned_step(
            new_step
        )

        self._replace_failed_step(
            new_step
        )

        self.metrics.increment(
            "verification_replans"
        )

        return new_step

    # ------------------------------------------------------------------
    # LOOP RECOVERY
    # ------------------------------------------------------------------

    async def _handle_loop(
        self,
        reason: str,
    ) -> None:

        state = self._require_state()

        error = AgentError(
            error_type="LoopDetected",
            message=reason,
            source="loop_detector",
            operation="execution",
            recoverable=True,
        )

        result = await self.reliability_engine.handle_failure(
            error=error,
            operation_name="loop_detection",
            recovery_operation=self._recover_loop,
        )

        if not result.success:

            state.tool_error = result.reason

            self.metrics.increment(
                "loop_recovery_failures"
            )

            self._emit_agent_failure(
                result.reason,
                error=result.error,
            )

    async def _recover_loop(
        self,
        error: AgentError,
    ) -> Any:

        state = self._require_state()

        if state.current_step >= len(state.plan):

            raise ValueError(
                "Cannot recover loop because "
                "current step is unavailable."
            )

        context = await self.context_builder.build(
            state
        )

        failed_step = state.plan[
            state.current_step
        ]

        new_step = await self.planner.replan_step(
            user_question=state.user_request,
            context=context.items,
            failed_step=failed_step,
            failure=error,
        )

        self._validate_replanned_step(
            new_step
        )

        self._replace_failed_step(
            new_step
        )

        self.metrics.increment(
            "loop_replans"
        )

        return new_step

    # ------------------------------------------------------------------
    # OBSERVABILITY
    # ------------------------------------------------------------------

    def emit_agent_started(
        self,
    ) -> None:

        state = self._require_state()

        self.event_logger.log(
            create_event(
                event_type=EventType.AGENT_STARTED,
                correlation_id=self.correlation_id,
                iteration=state.iteration,
            )
        )

        self.metrics.increment(
            "agents_started"
        )

    def emit_agent_completed(
        self,
    ) -> None:

        state = self._require_state()

        self.event_logger.log(
            create_event(
                event_type=EventType.AGENT_COMPLETED,
                correlation_id=self.correlation_id,
                iteration=state.iteration,
                metadata={
                    "final_answer_verified":
                        state.final_answer_verified,
                    "completed_steps":
                        len(
                            state.completed_steps
                        ),
                },
            )
        )

        self.metrics.increment(
            "agents_completed"
        )

    def _emit_agent_failure(
        self,
        reason: str,
        error: AgentError | None = None,
    ) -> None:

        state = self._require_state()

        self.event_logger.log(
            create_event(
                event_type=EventType.AGENT_FAILED,
                correlation_id=self.correlation_id,
                iteration=state.iteration,
                error=reason,
                metadata={
                    "error_type": (
                        error.error_type
                        if error
                        else None
                    ),
                    "source": (
                        error.source
                        if error
                        else None
                    ),
                    "operation": (
                        error.operation
                        if error
                        else None
                    ),
                },
            )
        )

