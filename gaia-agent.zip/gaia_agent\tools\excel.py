from __future__ import annotations

from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from smolagents import tool


class ExcelTools:
    """
    Excel tools for the GAIA agent.

    Reads Excel workbooks and provides their
    structured data to the LLM for analysis.
    """

    def __init__(
        self,
        model: Any = None,
        base_dir: str = ".",
    ) -> None:
        self.model = model
        self.base_dir = Path(base_dir).resolve()

    def _safe_path(
        self,
        file_path: str,
    ) -> Path:

        path = (
            self.base_dir / file_path
        ).resolve()

        if not path.is_relative_to(
            self.base_dir
        ):
            raise ValueError(
                "Unsafe path: access outside "
                "base directory."
            )

        return path

    def _read_excel(
        self,
        path: Path,
    ) -> str:

        workbook = load_workbook(
            filename=path,
            data_only=True,
            read_only=True,
        )

        try:
            output: list[str] = []

            for sheet in workbook.worksheets:

                output.append(
                    f"Sheet: {sheet.title}"
                )

                for row in sheet.iter_rows(
                    values_only=True
                ):

                    values = [
                        ""
                        if value is None
                        else str(value)
                        for value in row
                    ]

                    output.append(
                        " | ".join(values)
                    )

                output.append("")

            return "\n".join(output)

        finally:
            workbook.close()

    def get_tools(self) -> list:

        model = self.model
        base_dir = self.base_dir
        read_excel = self._read_excel

        @tool
        def analyze_excel(
            file_path: str,
            question: str,
        ) -> str:
            """
            Analyze an Excel file according to the user's question.

            Args:
                file_path: Excel file relative to the allowed directory.
                question: User's question about the Excel data.

            Returns:
                Answer based on the Excel data.
            """

            try:

                path = (
                    base_dir / file_path
                ).resolve()

                if not path.is_relative_to(
                    base_dir
                ):
                    return (
                        "Unsafe path: access outside "
                        "base directory."
                    )

                if not path.exists():
                    return (
                        f"File not found: {file_path}"
                    )

                if not path.is_file():
                    return (
                        f"Not a file: {file_path}"
                    )

                valid_extensions = {
                    ".xlsx",
                    ".xlsm",
                }

                if (
                    path.suffix.lower()
                    not in valid_extensions
                ):
                    return (
                        f"Unsupported Excel format: "
                        f"{path.suffix}"
                    )

                excel_data = read_excel(
                    path
                )

                if model is None:
                    return (
                        "LLM model is not configured."
                    )

                prompt = f"""
You are analyzing an Excel spreadsheet.

User question:
{question}

Excel data:
{excel_data}

Instructions:
- Answer the user's question using the spreadsheet data.
- Do not invent information.
- If the spreadsheet does not contain enough information,
  say that the required information is unavailable.
- Return only the requested answer.
"""

                answer = model.generate(
                    prompt
                )

                return str(answer)

            except Exception as exc:

                return (
                    f"Excel analysis error: {exc}"
                )

        return [
            analyze_excel
        ]
    