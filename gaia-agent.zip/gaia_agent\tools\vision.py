from __future__ import annotations

from pathlib import Path
from typing import Any

from smolagents import tool


class VisionTools:
    """
    Vision tools for the GAIA agent.
    """

    def __init__(
        self,
        model: Any,
        base_dir: str = ".",
    ) -> None:
        self.model = model
        self.base_dir = Path(base_dir).resolve()

    def _safe_path(
        self,
        file_path: str,
    ) -> Path:

        path = (
            self.base_dir / file_path
        ).resolve()

        if not path.is_relative_to(
            self.base_dir
        ):
            raise ValueError(
                "Access outside the allowed directory "
                "is not permitted."
            )

        return path

    def get_tools(self) -> list:

        model = self.model
        base_dir = self.base_dir

        @tool
        def analyze_image(
            image_path: str,
            question: str,
        ) -> str:
            """
            Analyze an image and answer a question about it.

            Args:
                image_path: Path to the image relative to the allowed directory.
                question: Question that should be answered using the image.

            Returns:
                The vision model's answer.
            """

            try:
                path = (
                    base_dir / image_path
                ).resolve()

                if not path.is_relative_to(
                    base_dir
                ):
                    return (
                        "Access outside the allowed "
                        "directory is not permitted."
                    )

                if not path.exists():
                    return (
                        f"Image not found: {image_path}"
                    )

                if not path.is_file():
                    return (
                        f"Not a file: {image_path}"
                    )

                valid_extensions = {
                    ".jpg",
                    ".jpeg",
                    ".png",
                    ".webp",
                    ".bmp",
                    ".gif",
                }

                if (
                    path.suffix.lower()
                    not in valid_extensions
                ):
                    return (
                        f"Unsupported image format: "
                        f"{path.suffix}"
                    )

                if model is None:
                    return (
                        "Vision model is not configured."
                    )

                prompt = (
                    "Analyze the provided image carefully.\n\n"
                    f"Question: {question}\n\n"
                    "Give a precise answer based only on "
                    "the visual information available "
                    "in the image."
                )

                response = model.generate(
                    prompt=prompt,
                    image=str(path),
                )

                return str(response)

            except Exception as exc:
                return (
                    f"Error analyzing image: {exc}"
                )

        return [
            analyze_image
        ]
    