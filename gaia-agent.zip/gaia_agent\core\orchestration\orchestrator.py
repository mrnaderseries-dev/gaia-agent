
from __future__ import annotations

from typing import Any
from uuid import UUID, uuid4

from gaia_agent.agents.answer_sanitizer import AnswerSanitizer
from gaia_agent.agents.verifier import (
    VerificationInput,
    VerifierAgent,
)

from gaia_agent.context.ContextBuilder import ContextBuilder

from gaia_agent.core.agent_execution import AgentExecution
from gaia_agent.core.agent_state import AgentState

from gaia_agent.planner.planner import Planner
from gaia_agent.planner.plan_schema import (
    PlanSchema,
    PlanStep,
    StepType,
)

from gaia_agent.reliability.engine import ReliabilityEngine
from gaia_agent.reliability.error_handler import ErrorHandler
from gaia_agent.reliability.errors import AgentError
from gaia_agent.reliability.loop_detection import LoopDetector

from gaia_agent.observability.events import (
    EventType,
    create_event,
)
from gaia_agent.observability.logger import EventLogger
from gaia_agent.observability.metrics import Metrics
from gaia_agent.observability.tracer import Tracer


class Orchestrator:
    """
    Coordinates the agent workflow.

    Responsibilities
    ----------------
    - build context
    - create the initial plan
    - coordinate full-plan replanning
    - coordinate single-step replanning
    - validate plans and replacement steps
    - detect execution loops
    - prepare AgentState for execution
    - delegate execution to AgentExecution
    - delegate retry/recovery decisions to ReliabilityEngine
    - replace failed steps after replan
    - coordinate final-answer generation
    - sanitize final answers
    - verify final answers
    - emit workflow-level observability

    Does NOT
    --------
    - execute tools directly
    - execute LLM calls directly
    - implement retry
    - implement recovery policy
    - classify failures
    - evaluate risk
    - evaluate approval
    - execute tools
    - execute the verifier directly through an LLM
    """

    def __init__(
        self,
        *,
        context_builder: ContextBuilder,
        planner: Planner,
        agent_execution: AgentExecution,
        error_handler: ErrorHandler,
        reliability_engine: ReliabilityEngine,
        loop_detector: LoopDetector,
        verifier: VerifierAgent,
        answer_sanitizer: AnswerSanitizer,
        event_logger: EventLogger,
        metrics: Metrics,
        tracer: Tracer,
    ) -> None:

        self.context_builder = context_builder
        self.planner = planner
        self.agent_execution = agent_execution

        self.error_handler = error_handler
        self.reliability_engine = reliability_engine
        self.loop_detector = loop_detector

        self.verifier = verifier
        self.answer_sanitizer = answer_sanitizer

        self.event_logger = event_logger
        self.metrics = metrics
        self.tracer = tracer

        self.state: AgentState | None = None

        self.correlation_id: UUID = uuid4()


    def bind_state(
        self,
        state: AgentState,
    ) -> None:

        self.state = state

        self.agent_execution.bind_state(
            state
        )

    def _require_state(
        self,
    ) -> AgentState:

        if self.state is None:
            raise RuntimeError(
                "AgentState is not bound. "
                "Call bind_state() before execution."
            )

        return self.state

   
    async def run_iteration(
        self,
    ) -> None:

        state = self._require_state()

        span = self.tracer.start_span(
            operation="orchestrator.iteration",
            correlation_id=self.correlation_id,
        )

        try:

            context = await self.context_builder.build(
                state
            )

            self.metrics.increment(
                "context_builds"
            )


            if not state.plan:

                await self._create_plan(
                    context.items
                )

                if state.tool_error is not None:
                    return

          
            if state.current_step >= len(state.plan):

                await self._handle_plan_completion()

                return

          
            step = state.plan[
                state.current_step
            ]

           
            loop_result = self.loop_detector.check(
                action=step.action,
                tool_name=step.tool_name,
                arguments=step.arguments,
            )

            if loop_result.detected:

                await self._handle_loop(
                    loop_result.message
                )

                return

           

            self._prepare_step(
                step
            )

           

            result = await self.reliability_engine.execute(
                operation=self.agent_execution.execute,
                operation_name="agent_execution",
                source="orchestrator",
                validator=self._validate_execution_result,
                recovery_operation=self._recover_execution,
            )

          

            if result.recovery_attempted:

                await self._handle_execution_recovery(
                    result
                )

                return

          
            if not result.success:

                state.tool_error = result.reason

                self.metrics.increment(
                    "agent_execution_failures"
                )

                self._emit_agent_failure(
                    result.reason,
                    error=result.error,
                )

                return


            if state.blocked:

                self.metrics.increment(
                    "execution_blocked"
                )

                return

            self._capture_step_result(
                step
            )

          

            self._mark_step_completed(
                step
            )

        except Exception as exc:

            error = self.error_handler.handle(
                exc,
                source="orchestrator",
                operation="run_iteration",
            )

            state.tool_error = error.message

            self.metrics.increment(
                "agent_errors"
            )

            self._emit_agent_failure(
                error.message,
                error=error,
            )

        finally:

            self.tracer.end_span(
                span,
                error=(
                    state.tool_error
                    if state.tool_error
                    else None
                ),
            )

    async def _create_plan(
        self,
        context: list[Any],
    ) -> None:

        state = self._require_state()

        result = await self.reliability_engine.execute(
            operation=lambda: self._generate_plan(
                user_question=state.user_request,
                context=context,
            ),
            operation_name="generate_plan",
            source="planner",
            validator=self._validate_plan_result,
            recovery_operation=self._replan_full_plan,
        )


        if result.recovery_attempted:

            if not result.success:

                state.tool_error = result.reason

                self.metrics.increment(
                    "planning_failures"
                )

                self._emit_agent_failure(
                    result.reason,
                    error=result.error,
                )

                return

            if not isinstance(
                result.result,
                PlanSchema,
            ):

                error = self.error_handler.handle(
                    TypeError(
                        "Recovery produced an invalid "
                        "plan type."
                    ),
                    source="planner",
                    operation="replan",
                )

                state.tool_error = error.message

                self.metrics.increment(
                    "planning_failures"
                )

                self._emit_agent_failure(
                    error.message,
                    error=error,
                )

                return

            self._apply_full_plan(
                result.result
            )

            return

      
        if not result.success:

            state.tool_error = result.reason

            self.metrics.increment(
                "planning_failures"
            )

            self._emit_agent_failure(
                result.reason,
                error=result.error,
            )

            return

        plan = result.result

        if not isinstance(
            plan,
            PlanSchema,
        ):

            error = self.error_handler.handle(
                TypeError(
                    "Planner returned an invalid "
                    "result type."
                ),
                source="planner",
                operation="generate_plan",
            )

            state.tool_error = error.message

            self.metrics.increment(
                "planning_failures"
            )

            self._emit_agent_failure(
                error.message,
                error=error,
            )

            return

        self._apply_full_plan(
            plan
        )

    async def _generate_plan(
        self,
        *,
        user_question: str,
        context: list[Any],
    ) -> PlanSchema:

        return await self.planner.generate_plan(
            user_question=user_question,
            context=context,
        )

    def _apply_full_plan(
        self,
        plan: PlanSchema,
    ) -> None:

        state = self._require_state()

        state.plan = list(
            plan.steps
        )

        state.current_step = 0

        state.completed_steps.clear()

        state.tool_result = None
        state.tool_error = None

        state.final_answer = None
        state.final_answer_ready = False
        state.final_answer_verified = False

        state.blocked = False

        state.execution_decision = None
        state.approval_decision = None
        state.risk_assessment = None

        self.metrics.increment(
            "plans_created"
        )

    async def _replan_full_plan(
        self,
        error: AgentError,
    ) -> PlanSchema:

        state = self._require_state()

        context = await self.context_builder.build(
            state
        )

        new_plan = await self.planner.replan(
            user_question=state.user_request,
            context=context.items,
            previous_plan=PlanSchema(
                steps=list(state.plan)
            ),
            failure_reason=error.message,
        )

        self._validate_plan(
            new_plan
        )

        loop_result = self.loop_detector.check_plan(
            new_plan.steps
        )

        if loop_result.detected:

            raise ValueError(
                "Planner produced a repeated plan."
            )

        self._apply_full_plan(
            new_plan
        )

        self.metrics.increment(
            "replans"
        )

        return new_plan

    def _validate_plan_result(
        self,
        plan: Any,
    ) -> bool:

        if not isinstance(
            plan,
            PlanSchema,
        ):
            return False

        try:

            self._validate_plan(
                plan
            )

        except (ValueError, TypeError):

            return False

        loop_result = self.loop_detector.check_plan(
            plan.steps
        )

        return not loop_result.detected

    def _validate_plan(
        self,
        plan: PlanSchema,
    ) -> None:

        if not plan.steps:

            raise ValueError(
                "Plan must contain at least one step."
            )

        expected_step_id = 0

        for step in plan.steps:

            if step.step_id != expected_step_id:

                raise ValueError(
                    "Plan step IDs must be sequential "
                    "starting from 0."
                )

            self._validate_step(
                step
            )

            expected_step_id += 1

    def _validate_step(
        self,
        step: PlanStep,
    ) -> None:

        if not step.action.strip():

            raise ValueError(
                f"Step {step.step_id} "
                "has an empty action."
            )

        if step.step_type == StepType.TOOL:

            if not step.tool_name:

                raise ValueError(
                    f"Tool step {step.step_id} "
                    "must specify tool_name."
                )

        elif step.step_type == StepType.LLM:

            if step.tool_name is not None:

                raise ValueError(
                    f"LLM step {step.step_id} "
                    "must not specify tool_name."
                )

        else:

            raise ValueError(
                f"Unsupported step type: "
                f"{step.step_type}"
            )

    async def _recover_execution(
        self,
        error: AgentError,
    ) -> PlanStep:

        state = self._require_state()

        if state.current_step >= len(
            state.plan
        ):

            raise ValueError(
                "Cannot replan because the current "
                "step does not exist."
            )

        failed_step = state.plan[
            state.current_step
        ]

        context = await self.context_builder.build(
            state
        )

        new_step = await self.planner.replan_step(
            user_question=state.user_request,
            context=context.items,
            failed_step=failed_step,
            failure=error,
        )

        self._validate_step(
            new_step
        )

        return new_step

    async def _handle_execution_recovery(
        self,
        result: Any,
    ) -> None:

        state = self._require_state()

        if not result.success:

            state.tool_error = result.reason

            self.metrics.increment(
                "recovery_failures"
            )

            self._emit_agent_failure(
                result.reason,
                error=result.error,
            )

            return

        new_step = result.result

        if not isinstance(
            new_step,
            PlanStep,
        ):

            error = self.error_handler.handle(
                TypeError(
                    "Recovery did not produce "
                    "a PlanStep."
                ),
                source="orchestrator",
                operation="execution_recovery",
            )

            state.tool_error = error.message

            self.metrics.increment(
                "recovery_failures"
            )

            self._emit_agent_failure(
                error.message,
                error=error,
            )

            return

        self._replace_failed_step(
            new_step
        )

        self._prepare_step(
            new_step
        )

        self.metrics.increment(
            "step_replans"
        )

    def _replace_failed_step(
        self,
        new_step: PlanStep,
    ) -> None:

        state = self._require_state()

        failed_index = state.current_step

        replacement = PlanStep(
            step_id=failed_index,
            action=new_step.action,
            step_type=new_step.step_type,
            tool_name=new_step.tool_name,
            arguments=dict(
                new_step.arguments or {}
            ),
            is_final_answer=getattr(
                new_step,
                "is_final_answer",
                False,
            ),
        )

        state.plan[
            failed_index
        ] = replacement

        state.tool_result = None
        state.tool_error = None

        state.blocked = False

        state.execution_decision = None
        state.approval_decision = None
        state.risk_assessment = None

    def _prepare_step(
        self,
        step: PlanStep,
    ) -> None:

        state = self._require_state()

        state.current_action = step.action

        state.step_type = step.step_type

        state.tool_name = step.tool_name

        state.tool_arguments = dict(
            step.arguments or {}
        )

        state.tool_result = None
        state.tool_error = None

        state.blocked = False

        state.execution_decision = None
        state.approval_decision = None
        state.risk_assessment = None
    @staticmethod
    def _validate_execution_result(
        state: AgentState,
    ) -> bool:

        if state.blocked:
            return True

        if state.tool_error is not None:
            return False

        return True

    def _capture_step_result(
        self,
        step: PlanStep,
    ) -> None:

        state = self._require_state()

        if not getattr(
            step,
            "is_final_answer",
            False,
        ):

            return

        if state.tool_result is None:

            raise ValueError(
                "Final answer generation "
                "returned no result."
            )

        candidate_answer = (
            self.answer_sanitizer.sanitize(
                state.tool_result
            )
        )

        state.final_answer = candidate_answer

        state.final_answer_ready = True

    def _mark_step_completed(
        self,
        step: PlanStep,
    ) -> None:

        state = self._require_state()

        if state.current_step not in (
            state.completed_steps
        ):

            state.completed_steps.append(
                state.current_step
            )

        state.current_step += 1

        state.retry_count = 0
        state.recovery_attempted = False

        self.metrics.increment(
            "steps_completed"
        )

 
    async def _handle_plan_completion(
        self,
    ) -> None:

        state = self._require_state()

      

        if not state.final_answer_ready:

            self._create_final_answer_step()

            return

       

        if not state.final_answer_verified:

            await self._verify_final_answer()

    def _create_final_answer_step(
        self,
    ) -> None:

        state = self._require_state()

        step_id = len(
            state.plan
        )

        state.plan.append(
            PlanStep(
                step_id=step_id,
                action=(
                    "Generate final answer "
                    "from gathered results."
                ),
                step_type=StepType.LLM,
                tool_name=None,
                arguments={},
                is_final_answer=True,
            )
        )

        self.metrics.increment(
            "final_answer_generation_steps"
        )

   

    async def _verify_final_answer(
        self,
    ) -> None:

        state = self._require_state()

        if state.final_answer is None:

            error = self.error_handler.handle(
                ValueError(
                    "Final answer is missing."
                ),
                source="orchestrator",
                operation="verify_answer",
            )

            state.tool_error = error.message

            self.metrics.increment(
                "verification_failures"
            )

            self._emit_agent_failure(
                error.message,
                error=error,
            )

            return

        context = await self.context_builder.build(
            state
        )

        self.metrics.increment(
            "verification_context_builds"
        )

        verification_input = VerificationInput(
            question=state.user_request,
            candidate_answer=state.final_answer,
            raw_data=context.items,
        )

        result = await self.reliability_engine.execute(
            operation=lambda: self.verifier.verify(
                verification_input
            ),
            operation_name="verify_answer",
            source="verifier",
            validator=self._validate_verification_result,
        )

        if not result.success:

            state.tool_error = result.reason

            self.metrics.increment(
                "verification_failures"
            )

            self._emit_agent_failure(
                result.reason,
                error=result.error,
            )

            return

        verification = result.result

        if verification is None:

            state.tool_error = (
                "Verifier returned no result."
            )

            self.metrics.increment(
                "verification_failures"
            )

            return

   
        if not verification.verified:

            error = AgentError(
                error_type="AnswerVerificationError",
                message=verification.reason,
                source="verifier",
                operation="verify_answer",
                recoverable=True,
            )

            await self._handle_verification_failure(
                error
            )

            return

       

        state.final_answer = (
            self.answer_sanitizer.sanitize(
                verification.answer
            )
        )

        state.final_answer_ready = True
        state.final_answer_verified = True

        self.metrics.increment(
            "answers_verified"
        )

    async def _handle_verification_failure(
        self,
        error: AgentError,
    ) -> None:

        state = self._require_state()

        classification = (
            self.reliability_engine.failure_classifier.classify(
                error
            )
        )

        recovery_decision = (
            self.reliability_engine.recovery_policy.evaluate(
                classification
            )
        )

        if recovery_decision.action.name != "REPLAN":

            state.tool_error = (
                recovery_decision.reason
            )

            self.metrics.increment(
                "verification_failures"
            )

            self._emit_agent_failure(
                recovery_decision.reason,
                error=error,
            )

            return

        failed_step = self._find_final_answer_step()

        if failed_step is None:

            state.tool_error = (
                "Final answer step could not be found."
            )

            self.metrics.increment(
                "verification_failures"
            )

            self._emit_agent_failure(
                state.tool_error,
                error=error,
            )

            return

        context = await self.context_builder.build(
            state
        )

        try:

            new_step = await self.planner.replan_step(
                user_question=state.user_request,
                context=context.items,
                failed_step=failed_step,
                failure=error,
            )

            self._validate_step(
                new_step
            )

        except Exception as exc:

            recovery_error = self.error_handler.handle(
                exc,
                source="planner",
                operation="replan_step",
            )

            state.tool_error = (
                recovery_error.message
            )

            self.metrics.increment(
                "verification_recovery_failures"
            )

            self._emit_agent_failure(
                recovery_error.message,
                error=recovery_error,
            )

            return

        self._replace_failed_step(
            new_step
        )

        self._prepare_step(
            new_step
        )

        state.final_answer = None
        state.final_answer_ready = False
        state.final_answer_verified = False

        self.metrics.increment(
            "answer_replans"
        )

    def _find_final_answer_step(
        self,
    ) -> PlanStep | None:

        state = self._require_state()

        for step in reversed(
            state.plan
        ):

            if getattr(
                step,
                "is_final_answer",
                False,
            ):

                return step

        return None

    @staticmethod
    def _validate_verification_result(
        result: Any,
    ) -> bool:

        return result is not None

  

    async def _handle_loop(
        self,
        reason: str,
    ) -> None:

        state = self._require_state()

        error = AgentError(
            error_type="LoopDetected",
            message=reason,
            source="loop_detector",
            operation="execution",
            recoverable=True,
        )

        classification = (
            self.reliability_engine.failure_classifier.classify(
                error
            )
        )

        recovery_decision = (
            self.reliability_engine.recovery_policy.evaluate(
                classification
            )
        )

        if recovery_decision.action.name != "REPLAN":

            state.tool_error = (
                recovery_decision.reason
            )

            self.metrics.increment(
                "loop_recovery_failures"
            )

            self._emit_agent_failure(
                recovery_decision.reason,
                error=error,
            )

            return

        if state.current_step >= len(
            state.plan
        ):

            state.tool_error = (
                "Loop recovery has no current step."
            )

            self.metrics.increment(
                "loop_recovery_failures"
            )

            self._emit_agent_failure(
                state.tool_error,
                error=error,
            )

            return

        failed_step = state.plan[
            state.current_step
        ]

        context = await self.context_builder.build(
            state
        )

        try:

            new_step = await self.planner.replan_step(
                user_question=state.user_request,
                context=context.items,
                failed_step=failed_step,
                failure=error,
            )

            self._validate_step(
                new_step
            )

        except Exception as exc:

            recovery_error = self.error_handler.handle(
                exc,
                source="planner",
                operation="replan_step",
            )

            state.tool_error = (
                recovery_error.message
            )

            self.metrics.increment(
                "loop_recovery_failures"
            )

            self._emit_agent_failure(
                recovery_error.message,
                error=recovery_error,
            )

            return

        self._replace_failed_step(
            new_step
        )

        self._prepare_step(
            new_step
        )

        self.metrics.increment(
            "loop_recoveries"
        )


    def emit_agent_started(
        self,
    ) -> None:

        state = self._require_state()

        self.event_logger.log(
            create_event(
                event_type=EventType.AGENT_STARTED,
                correlation_id=self.correlation_id,
                iteration=state.iteration,
            )
        )

        self.metrics.increment(
            "agents_started"
        )

    def emit_agent_completed(
        self,
    ) -> None:

        state = self._require_state()

        self.event_logger.log(
            create_event(
                event_type=EventType.AGENT_COMPLETED,
                correlation_id=self.correlation_id,
                iteration=state.iteration,
                metadata={
                    "final_answer_verified":
                        state.final_answer_verified,
                    "completed_steps":
                        len(
                            state.completed_steps
                        ),
                },
            )
        )

        self.metrics.increment(
            "agents_completed"
        )

    def _emit_agent_failure(
        self,
        reason: str,
        error: AgentError | None = None,
    ) -> None:

        state = self._require_state()

        self.event_logger.log(
            create_event(
                event_type=EventType.AGENT_FAILED,
                correlation_id=self.correlation_id,
                iteration=state.iteration,
                error=reason,
                metadata={
                    "error_type": (
                        error.error_type
                        if error
                        else None
                    ),
                    "source": (
                        error.source
                        if error
                        else None
                    ),
                    "operation": (
                        error.operation
                        if error
                        else None
                    ),
                },
            )
        )
