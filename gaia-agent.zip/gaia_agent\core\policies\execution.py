from __future__ import annotations
from gaia_agent.planner.plan_schema import StepType,PlanStep
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Any


class ExecutionReason(str, Enum):
    ACTION = "action"
    TOOL = "tool"
    ARGUMENT = "argument"
    BLOCKED = "blocked"


@dataclass(frozen=True)
class ExecutionDecision:
    allowed: bool
    reason: Optional[str] = None
    message: Optional[str] = None

    @classmethod
    def allow(cls):
        return cls(allowed=True)

    @classmethod
    def deny(cls, reason: str, message: str):
        return cls(allowed=False, reason=reason, message=message)


@dataclass(frozen=True)
class ExecutionState:
    step_type:StepType
    tool_name: str | None
    action_name: str | None
    arguments: dict[str, Any]
    blocked: bool = False

class ExecutionPolicy:
    """this class is check if there a specific statements related to the state that make us stop the agent loop"""
    
    priority = [
        "Action",
        "Tool",
        "Argument",
        "blocked"
    ]

    def evaluate(self, stat: ExecutionState) -> ExecutionDecision:
        if not stat.action_name:
            return ExecutionDecision.deny(
                reason=ExecutionReason.ACTION,
                message="action name not found"
            )
        if not stat.tool_name:
            return ExecutionDecision.deny(
                reason=ExecutionReason.TOOL,
                message="tool name not found"
            )
        if not stat.arguments:
            return ExecutionDecision.deny(
                reason=ExecutionReason.ARGUMENT,
                message="argument not found"
            )
        if stat.blocked:
            return ExecutionDecision.deny(
                reason=ExecutionReason.BLOCKED,
                message="we cannot do anything due the block"
            )
        
        return ExecutionDecision.allow()
