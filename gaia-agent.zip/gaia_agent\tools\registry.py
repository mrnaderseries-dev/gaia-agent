from .files import FileTools
from .audio import AudioTools
from .vision import VisionTools
from .excel import ExcelTools
from .python import PythonTools
from .web import WebTools


class ToolRegistry:
    """
    Central registry for all GAIA agent tools.
    """

    def __init__(self,base_dir: str = ".",model=None,stt_backend=None):
        self.base_dir = base_dir
        self.model = model
        self.stt_backend = stt_backend

    def get_tools(self) -> list:
        """
        Create and return all tools available to the agent.
        """

        file_tools = FileTools(base_dir=self.base_dir)

        audio_tools = AudioTools(stt_backend=self.stt_backend,base_dir=self.base_dir,model=self.model)

        vision_tools = VisionTools(base_dir=self.base_dir,model=self.model)

        excel_tools = ExcelTools(base_dir=self.base_dir,model=self.model)

        python_tools = PythonTools(base_dir=self.base_dir)

        web_tools = WebTools()

        tools = []

        tools.extend(file_tools.get_tools())
        tools.extend(audio_tools.get_tools())
        tools.extend(vision_tools.get_tools())
        tools.extend(excel_tools.get_tools())
        tools.extend(python_tools.get_tools())
        tools.extend(web_tools.get_tools())

        return tools