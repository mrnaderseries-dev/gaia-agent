from __future__ import annotations

from gaia_agent.core.agent_execution import AgentExecution
from gaia_agent.core.agent_state import AgentState
from gaia_agent.core.orchestration.orchestrator import Orchestrator
from gaia_agent.core.policies.termination import (
    TerminationDecision,
    TerminationPolicy,
    TerminationState,
)


class AgentLoop:

    def __init__(
        self,
        *,
        orchestrator: Orchestrator,
        agent_execution: AgentExecution,
        termination_policy: TerminationPolicy,
    ) -> None:

        self.orchestrator = orchestrator
        self.agent_execution = agent_execution
        self.termination_policy = termination_policy

    async def run(
        self,
        state: AgentState,
    ) -> AgentState:

        self.orchestrator.bind_state(state)

        self.orchestrator.emit_agent_started()

        while True:

            termination = self.check_termination()

            if termination.should_stop:
                break

            await self.orchestrator.run_iteration()

            state.iteration += 1

        self.orchestrator.emit_agent_completed()

        return state

    def check_termination(
        self,
    ) -> TerminationDecision:

        state = self._require_state()

        termination_state = TerminationState(
            iteration=state.iteration,
            max_iterations=self.termination_policy.max_iterations,
            final_answer_ready=state.final_answer_verified,
            fatal_error=state.fatal_error,
            human_aborted=state.human_aborted,
            explicit_stop=state.explicit_stop,
            timed_out=state.timed_out,
        )

        decision = self.termination_policy.evaluate(
            termination_state
        )

        if decision.should_stop:
            state.termination_reason = decision.reason

        return decision

    def _require_state(self) -> AgentState:

        if self.agent_execution.state is None:
            raise RuntimeError(
                "AgentState is not bound."
            )

        return self.agent_execution.state