from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

from pydantic import BaseModel, Field

from gaia_agent.llm.client import LLMClient
from gaia_agent.llm.model import LLMModel


class VerificationResult(BaseModel):
    verified: bool
    answer_supported: bool
    answer: str
    reason: str
    evidence_used: list[str] = Field(
        default_factory=list
    )


@dataclass(frozen=True, slots=True)
class VerificationInput:
    question: str
    candidate_answer: str
    raw_data: Sequence[Any]


class VerifierAgent:
    """
    Verifies whether a candidate answer is supported
    by the collected data.
    """

    def __init__(
        self,
        client: LLMClient,
        model: LLMModel,
    ) -> None:

        self.client = client
        self.model = model

    async def verify(
        self,
        data: VerificationInput,
    ) -> VerificationResult:

        if not data.question.strip():
            raise ValueError(
                "question cannot be empty."
            )

        if not data.candidate_answer.strip():
            raise ValueError(
                "candidate_answer cannot be empty."
            )

        messages = self._build_messages(
            data
        )

        result = await self.client.generate(
            messages,
            model=self.model,
            output_schema=VerificationResult,
        )

        if not isinstance(
            result,
            VerificationResult,
        ):
            raise TypeError(
                "Verifier returned an invalid "
                "verification result."
            )

        return result

    def _build_messages(
        self,
        data: VerificationInput,
    ) -> list[dict[str, str]]:

        return [
            {
                "role": "system",
                "content": self._system_prompt(),
            },
            {
                "role": "user",
                "content": self._build_prompt(data),
            },
        ]

    @staticmethod
    def _system_prompt() -> str:

        return """
You are the verification component of an AI agent.

Your task is to determine whether the candidate
answer is supported by the provided raw data.

Rules:

1. Verify the candidate answer against the raw data.
2. Do not invent facts.
3. Set `verified` to true only when the answer is
   adequately supported by the raw data.
4. Set `answer_supported` according to the evidence.
5. If the candidate answer is not supported,
   explain why in `reason`.
6. `evidence_used` must contain only evidence actually
   present in the raw data.
7. The `answer` field must contain the best supported
   answer to the user's question.
8. Do not include reasoning in the `answer` field.
9. Do not include greetings or unnecessary prefixes.
10. Return only data matching the provided
    VerificationResult schema.
"""

    def _build_prompt(
        self,
        data: VerificationInput,
    ) -> str:

        raw_data = "\n\n".join(
            self._format_raw_item(item)
            for item in data.raw_data
        )

        return f"""
QUESTION:

{data.question}


CANDIDATE ANSWER:

{data.candidate_answer}


RAW DATA:

{raw_data}


Verify whether the candidate answer is supported
by the raw data.

If it is supported, return a verified result.

If it is not supported, explain the failure in
`reason` and provide the best supported answer
in `answer`.
"""

    @staticmethod
    def _format_raw_item(
        item: Any,
    ) -> str:

        if isinstance(item, str):
            return item

        if isinstance(item, dict):
            return str(item)

        return repr(item)