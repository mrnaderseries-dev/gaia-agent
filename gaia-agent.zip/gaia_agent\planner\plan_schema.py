from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator


class StepType(str, Enum):
    TOOL = "tool"
    LLM = "llm"

class PlanStep(BaseModel):
    step_id: int
    action: str
    step_type: StepType
    tool_name: str | None = None
    arguments: dict[str, Any] = Field(default_factory=dict)
    is_final_answer: bool = False    
    @field_validator("action")
    @classmethod
    def validate_action(cls, value: str) -> str:
        value = value.strip()

        if not value:
            raise ValueError("Step action cannot be empty.")

        return value

    @field_validator("tool_name")
    @classmethod
    def normalize_tool_name(
        cls,
        value: str | None,
    ) -> str | None:
        if value is None:
            return None

        value = value.strip()

        return value or None


class PlanSchema(BaseModel):
    steps: list[PlanStep] = Field(min_length=1)

    @field_validator("steps")
    @classmethod
    def validate_step_ids(
        cls,
        steps: list[PlanStep],
    ) -> list[PlanStep]:

        for expected_id, step in enumerate(steps):
            if step.step_id != expected_id:
                raise ValueError(
                    "Step IDs must be sequential starting from 0."
                )

        return steps