from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class TerminationReason(str, Enum):
    FINAL_ANSWER = "final_answer"
    MAX_ITERATIONS = "max_iterations"
    FATAL_ERROR = "fatal_error"
    
    EXPLICIT_STOP = "explicit_stop"
    TIMEOUT = "timeout"


@dataclass(frozen=True, slots=True)
class TerminationDecision:
    should_stop: bool
    reason: TerminationReason | None = None
    message: str | None = None

    @classmethod
    def continue_execution(
        cls,
    ) -> "TerminationDecision":
        return cls(
            should_stop=False,
        )

    @classmethod
    def stop(
        cls,
        reason: TerminationReason,
        message: str | None = None,
    ) -> "TerminationDecision":
        return cls(
            should_stop=True,
            reason=reason,
            message=message,
        )


@dataclass(frozen=True, slots=True)
class TerminationState:
   

    iteration: int = 0
    final_answer_ready: bool = False
    fatal_error: bool = False
    explicit_stop: bool = False
    timed_out: bool = False


class TerminationPolicy:
 

    def __init__(
        self,
        max_iterations: int | None = None,
    ) -> None:

        if (
            max_iterations is not None
            and max_iterations <= 0
        ):
            raise ValueError(
                "max_iterations must be greater than 0."
            )

        self.max_iterations = max_iterations

    def evaluate(
        self,
        state: TerminationState,
    ) -> TerminationDecision:

        if state.fatal_error:
            return TerminationDecision.stop(
                reason=TerminationReason.FATAL_ERROR,
                message=(
                    "Agent execution stopped because "
                    "of a fatal error."
                ),
            )
        if state.explicit_stop:
            return TerminationDecision.stop(
                reason=TerminationReason.EXPLICIT_STOP,
                message=(
                    "Agent execution was explicitly stopped."
                ),
            )

        if state.timed_out:
            return TerminationDecision.stop(
                reason=TerminationReason.TIMEOUT,
                message=(
                    "Agent execution stopped because "
                    "the time limit was reached."
                ),
            )

        if state.final_answer_ready:
            return TerminationDecision.stop(
                reason=TerminationReason.FINAL_ANSWER,
                message=(
                    "Agent produced a verified final answer."
                ),
            )

        if (
            self.max_iterations is not None
            and state.iteration >= self.max_iterations
        ):
            return TerminationDecision.stop(
                reason=TerminationReason.MAX_ITERATIONS,
                message=(
                    "Maximum number of iterations reached "
                    f"({self.max_iterations})."
                ),
            )

        return TerminationDecision.continue_execution()
    