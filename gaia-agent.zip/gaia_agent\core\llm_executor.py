from __future__ import annotations

from typing import Any

from gaia_agent.core.agent_state import AgentState
from gaia_agent.context.ContextBuilder import ContextBuilder
from gaia_agent.context.ContextBuilder import FinalContext
from gaia_agent.llm.client import LLMClient
from gaia_agent.llm.model import LLMModel


class LLMExecutor:

    def __init__(
        self,
        *,
        client: LLMClient,
        model: LLMModel,
        context_builder: ContextBuilder,
    ) -> None:

        self.client = client
        self.model = model
        self.context_builder = context_builder

    async def execute(
        self,
        state: AgentState,
    ) -> Any:

        context = await self.context_builder.build(
            state
        )

        messages = self._build_messages(
            state=state,
            context=context,
        )

        return await self.client.generate(
            messages=messages,
            model=self.model,
        )

    def _build_messages(
        self,
        *,
        state: AgentState,
        context: FinalContext,
    ) -> list[dict[str, str]]:

        return [
            {
                "role": "system",
                "content": (
                    "You are an execution component of an AI agent. "
                    "Use the provided context to perform the current "
                    "planned action. Do not invent information."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Current action:\n"
                    f"{state.current_action}\n\n"
                    f"Context:\n"
                    f"{context.items}"
                ),
            },
        ]
    