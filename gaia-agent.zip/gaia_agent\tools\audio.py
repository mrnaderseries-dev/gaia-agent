from __future__ import annotations

from pathlib import Path
from typing import Any

from smolagents import tool


class AudioTools:
    """
    Audio tools used by the GAIA agent.
    """

    def __init__(
        self,
        stt_backend: Any,
        base_dir: str = ".",
        model: Any = None,
    ) -> None:
        self.stt_backend = stt_backend
        self.base_dir = Path(base_dir).resolve()
        self.model = model

    def _safe_path(
        self,
        file_path: str,
    ) -> Path:

        path = (self.base_dir / file_path).resolve()

        if not path.is_relative_to(self.base_dir):
            raise ValueError(
                "Unsafe path: access outside base directory."
            )

        return path

    def get_tools(self) -> list:
        """
        Create and return audio tools.
        """

        stt_backend = self.stt_backend
        base_dir = self.base_dir
        model = self.model

        @tool
        def audio_analysis(
            file_path: str,
            question: str,
        ) -> str:
            """
            Analyze an audio file according to the user's question.

            Args:
                file_path: Audio file relative to the allowed directory.
                question: User's question about the audio.

            Returns:
                Answer based on the audio content and user question.
            """

            try:
                path = (
                    base_dir / file_path
                ).resolve()

                if not path.is_relative_to(
                    base_dir
                ):
                    return (
                        "Unsafe path: access outside "
                        "base directory."
                    )

                if not path.exists():
                    return (
                        f"File not found: {file_path}"
                    )

                if not path.is_file():
                    return (
                        f"Not a file: {file_path}"
                    )

                valid_extensions = {
                    ".mp3",
                    ".wav",
                    ".m4a",
                    ".flac",
                    ".ogg",
                }

                if path.suffix.lower() not in valid_extensions:
                    return (
                        f"Unsupported audio format: "
                        f"{path.suffix}"
                    )

                if stt_backend is None:
                    return (
                        "Audio transcription backend "
                        "is not configured."
                    )

                if model is None:
                    return (
                        "LLM model is not configured."
                    )

                audio_text = (
                    stt_backend.transcribe(
                        str(path)
                    )
                )

                prompt = f"""
You are analyzing an audio transcript.

User question:
{question}

Audio transcript:
{audio_text}

Instructions:
- Answer the user's question using only
  information available in the transcript.
- If the transcript is unclear or insufficient,
  return exactly:
  audio text not good
- Return only the requested information.
"""

                answer = model.generate(
                    prompt
                )

                return str(answer)

            except Exception as exc:
                return (
                    f"Audio analysis error: {exc}"
                )

        return [
            audio_analysis
        ]
    