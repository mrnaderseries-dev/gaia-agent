from __future__ import annotations

from pathlib import Path
from smolagents import tool


class FileTools:
    """
    File-system tools used by the GAIA agent.

    Provides:
    - List files
    - Check if a file exists
    - Read text files
    - Write text files
    """

    def __init__(self, base_dir: str = "."):
        self.base_dir = Path(base_dir).resolve()

    def _safe_path(self, file_path: str) -> Path:
        """
        Resolve a path and prevent access outside
        the allowed base directory.
        """
        path = (self.base_dir / file_path).resolve()

        if not path.is_relative_to(self.base_dir):
            raise ValueError(
                "Access outside the allowed directory "
                "is not permitted."
            )

        return path

    def list_files(
        self,
        directory: str = ".",
    ) -> str:
        """
        List files and directories inside a directory.

        Args:
            directory: Directory relative to the allowed
                base directory.

        Returns:
            A newline-separated list of entries.
        """
        try:
            path = self._safe_path(directory)

            if not path.exists():
                return f"Directory not found: {directory}"

            if not path.is_dir():
                return f"Not a directory: {directory}"

            entries = sorted(
                entry.name
                for entry in path.iterdir()
            )

            if not entries:
                return "Directory is empty."

            return "\n".join(entries)

        except Exception as exc:
            return f"Error listing files: {exc}"

    def file_exists(
        self,
        file_path: str,
    ) -> str:
        """
        Check whether a file exists.

        Args:
            file_path: File path relative to the allowed
                base directory.

        Returns:
            Whether the file exists.
        """
        try:
            path = self._safe_path(file_path)

            return (
                "True"
                if path.is_file()
                else "False"
            )

        except Exception as exc:
            return f"Error checking file: {exc}"

    def read_file(
        self,
        file_path: str,
    ) -> str:
        """
        Read a text file.

        Args:
            file_path: File path relative to the allowed
                base directory.

        Returns:
            The file contents.
        """
        try:
            path = self._safe_path(file_path)

            if not path.exists():
                return f"File not found: {file_path}"

            if not path.is_file():
                return f"Not a file: {file_path}"

            return path.read_text(
                encoding="utf-8"
            )

        except UnicodeDecodeError:
            return (
                "This file is not a UTF-8 text file."
            )

        except Exception as exc:
            return f"Error reading file: {exc}"

    def write_file(
        self,
        file_path: str,
        content: str,
    ) -> str:
        """
        Write text content to a file.

        Args:
            file_path: File path relative to the allowed
                base directory.

        Returns:
            Success or error message.
        """
        try:
            path = self._safe_path(file_path)

            path.parent.mkdir(
                parents=True,
                exist_ok=True,
            )

            path.write_text(
                content,
                encoding="utf-8",
            )

            return (
                f"File written successfully: "
                f"{file_path}"
            )

        except Exception as exc:
            return f"Error writing file: {exc}"

    def get_tools(self) -> list:
        """
        Return all file tools for the central tool registry.
        """

        @tool
        def list_files(
            directory: str = ".",
        ) -> str:
            """
            List files and directories inside a directory.

            Args:
                directory: Directory relative to the
                    allowed base directory.

            Returns:
                A newline-separated list of entries.
            """
            return self.list_files(directory)

        @tool
        def file_exists(
            file_path: str,
        ) -> str:
            """
            Check whether a file exists.

            Args:
                file_path: File path relative to the
                    allowed base directory.

            Returns:
                Whether the file exists.
            """
            return self.file_exists(file_path)

        @tool
        def read_file(
            file_path: str,
        ) -> str:
            """
            Read a text file.

            Args:
                file_path: File path relative to the
                allowed base directory.

            Returns:
                The file contents.
            """
            return self.read_file(file_path)

        @tool
        def write_file(
            file_path: str,
            content: str,
        ) -> str:
            """
            Write text content to a file.

            Args:
                file_path: File path relative to the
                allowed base directory.

            Returns:
                Success or error message.
            """
            return self.write_file(
                file_path,
                content,
            )

        return [
            list_files,
            file_exists,
            read_file,
            write_file,
        ]
    