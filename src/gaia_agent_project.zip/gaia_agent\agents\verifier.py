from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel, Field

from gaia_agent.llm.client import LLMClient
from gaia_agent.llm.model import LLMModel


class VerificationResult(BaseModel):
    verified: bool = Field(
        description=(
            "Whether the candidate answer is supported "
            "by the available data."
        )
    )
    reason: str = Field(
        description=(
            "Brief explanation for the verification decision."
        )
    )


class VerificationInput(BaseModel):
    question: str
    candidate_answer: str
    raw_data: list[Any] = Field(
        default_factory=list
    )


class VerifierAgent:
    """
    Verifies whether a candidate final answer is supported by
    the information gathered during agent execution.

    The verifier is a judge only.

    It does NOT:
    - generate a replacement answer
    - modify the candidate answer
    - execute tools
    - perform recovery
    - replan

    It only returns a VerificationResult.
    """

    def __init__(
        self,
        *,
        client: LLMClient,
        model: LLMModel,
    ) -> None:

        self.client = client
        self.model = model

    async def verify(
        self,
        data: VerificationInput,
    ) -> VerificationResult:
        """
        Verify a candidate answer against the available raw data.
        """

        messages = self._build_messages(
            data
        )

        result = await self.client.generate(
            messages=messages,
            model=self.model,
            output_schema=VerificationResult,
        )

        if not isinstance(
            result,
            VerificationResult,
        ):
            raise TypeError(
                "LLMClient.generate() returned an invalid "
                "verification result."
            )

        return result

    def _build_messages(
        self,
        data: VerificationInput,
    ) -> list[dict[str, str]]:
        """
        Build the messages sent to the verification LLM.
        """

        return [
            {
                "role": "system",
                "content": self._system_prompt(),
            },
            {
                "role": "user",
                "content": self._build_prompt(
                    data
                ),
            },
        ]

    @staticmethod
    def _system_prompt() -> str:
        """
        System instructions for the verifier.

        The verifier must judge factual support only and must
        not invent information.
        """

        return (
            "You are a strict answer verification agent.\n\n"

            "Your task is to determine whether the candidate "
            "answer is supported by the provided information.\n\n"

            "Rules:\n"

            "1. Verify the answer against the provided raw data.\n"

            "2. Do not use unsupported assumptions.\n"

            "3. Do not invent facts.\n"

            "4. Do not rewrite or improve the candidate answer.\n"

            "5. Return verified=true only when the candidate "
            "answer is adequately supported by the available "
            "information.\n"

            "6. Return verified=false when the answer is "
            "unsupported, contradicted, incomplete in a materially "
            "important way, or otherwise unreliable.\n"

            "7. Give a concise reason for the decision.\n"
            "8. Single-word or exact-number answers are valid as long as they are factually supported by the raw data."
        )

    @staticmethod
    def _build_prompt(
        data: VerificationInput,
    ) -> str:
        """
        Build the user prompt containing the question,
        candidate answer, and gathered data.
        """

        raw_data = "\n".join(
            VerifierAgent._format_raw_item(
                item
            )
            for item in data.raw_data
        )

        if not raw_data:
            raw_data = "(No raw data was provided.)"

        return (
            "Verify the following candidate answer.\n\n"

            f"Question:\n{data.question}\n\n"

            f"Candidate answer:\n{data.candidate_answer}\n\n"

            "Available raw data:\n"
            f"{raw_data}\n\n"

            "Determine whether the candidate answer is supported "
            "by the available raw data."
        )

    @staticmethod
    def _format_raw_item(
        item: Any,
    ) -> str:
        """
        Convert an arbitrary raw-data item into a safe textual
        representation for the verifier prompt.
        """

        if item is None:
            return "None"

        if isinstance(item, str):
            return item

        if isinstance(item, BaseModel):
            return item.model_dump_json(indent=2)

        if isinstance(item, (dict, list, tuple, set)):
            try:
                return json.dumps(item, default=str, indent=2)
            except Exception:
                return str(item)

        return str(item)