﻿import asyncio
import requests
import traceback
from gaia_agent import main as user_agent
from gaia_agent.core.agent_state import AgentState

API_URL = "https://agents-course-unit4-scoring.hf.space"
SPACE_ID = "Nadoura/gaia-agent-submission"
AGENT_CODE_URL = f"https://huggingface.co/spaces/{SPACE_ID}/tree/main"

async def main():
    print("Initializing Agent via create_agent()...")
    agent_instance = None
    try:
        if asyncio.iscoroutinefunction(user_agent.create_agent):
            agent_instance = await user_agent.create_agent()
        else:
            agent_instance = user_agent.create_agent()
    except Exception as e:
        print(f"Error initializing agent: {e}")

    print("Fetching 20 evaluation questions...")
    res = requests.get(f"{API_URL}/questions")
    questions = res.json()

    answers = []
    for idx, q in enumerate(questions, 1):
        task_id = q.get("task_id")
        question_text = q.get("Question", "")
        print(f"[{idx}/20] Processing Task ID: {task_id}...")
        
        agent_ans = "0"
        try:
            state = AgentState(user_request=question_text, user_id="evaluation_user")
            # تعيين السؤال في الحقل الصحيح اللي بيطلبه النظام
            if hasattr(state, "user_question"):
                state.user_question = question_text
            for attr in ["prompt", "query", "question", "input", "task", "text"]:
                if hasattr(state, attr):
                    setattr(state, attr, question_text)

            if agent_instance is not None:
                if hasattr(agent_instance, "run"):
                    if asyncio.iscoroutinefunction(agent_instance.run):
                        agent_ans = await agent_instance.run(state)
                    else:
                        agent_ans = agent_instance.run(state)
                elif callable(agent_instance):
                    agent_ans = agent_instance(state)
            elif hasattr(user_agent, "run"):
                agent_ans = user_agent.run(state)
            
            if hasattr(agent_ans, "final_answer"):
                agent_ans = agent_ans.final_answer
        except Exception as e:
            print(f"Execution error on task {task_id}: {e}")
            traceback.print_exc()
            agent_ans = "0"
            
        answers.append({
            "task_id": task_id,
            "submitted_answer": str(agent_ans).strip() if agent_ans is not None else "0"
        })

    print("\nSubmitting answers to Hugging Face Leaderboard...")
    submission_payload = {
        "username": "Nadoura",
        "agent_code": AGENT_CODE_URL,
        "answers": answers
    }

    sub_res = requests.post(f"{API_URL}/submit", json=submission_payload)
    print("\nFinal Result:")
    print(sub_res.json())

if __name__ == "__main__":
    asyncio.run(main())

