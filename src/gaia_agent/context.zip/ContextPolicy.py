from __future__ import annotations

from enum import IntEnum


class ContextPriority(IntEnum):
    DISCARD = 0
    COMPRESS = 1
    PRESERVE = 2


class ContextPolicy:

    include_memory: bool = False
    include_conversation: bool = True
    include_history: bool = True
    include_runtime: bool = True

    conversation_priority = ContextPriority.PRESERVE
    memory_priority = ContextPriority.COMPRESS
    history_priority = ContextPriority.COMPRESS
    runtime_priority = ContextPriority.COMPRESS