from smolagents import (
    DuckDuckGoSearchTool,
    VisitWebpageTool,
)


class WebTools:
    """
    Web tools used by the GAIA agent.

    Provides:
    - Web search
    - Webpage visiting and content extraction
    """

    def __init__(self):
        self.search = DuckDuckGoSearchTool()
        self.visit = VisitWebpageTool()

    def get_tools(self) -> list:
        """
        Return all web tools as a list.
        """

        return [
            self.search,
            self.visit,
        ]