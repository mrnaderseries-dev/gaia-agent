from __future__ import annotations

from typing import Any
from uuid import UUID

from gaia_agent.reliability.errors import (
    AgentError,
    ErrorCategory,
    ErrorSeverity,
)

from gaia_agent.reliability.exception import (
    AgentRuntimeError,
    AuthenticationError,
    AuthorizationError,
    RateLimitError,
    ToolExecutionError,
    ModelExecutionError,
    ValidationError,
    NetworkError,
    InternalAgentError,
    ContextCompressionError,
)


class ErrorHandler:

    def handle(
        self,
        error: Exception,
        *,
        source: str | None = None,
        operation: str | None = None,
        attempt: int = 0,
        correlation_id: UUID | None = None,
        details: dict[str, Any] | None = None,
    ) -> AgentError:

        if attempt < 0:
            raise ValueError(
                "attempt cannot be negative."
            )

        return AgentError(
            error_type=type(error).__name__,
            message=str(error),
            category=self._get_category(error),
            severity=self._get_severity(error),
            retryable=self._is_retryable(error),
            recoverable=self._is_recoverable(error),
            source=source,
            operation=operation,
            attempt=attempt,
            details=dict(details or {}),
            original_exception=error,
            correlation_id=correlation_id,
        )

    def _get_category(
        self,
        error: Exception,
    ) -> ErrorCategory:

        if isinstance(error, AuthenticationError):
            return ErrorCategory.AUTHENTICATION

        if isinstance(error, AuthorizationError):
            return ErrorCategory.AUTHORIZATION

        if isinstance(error, RateLimitError):
            return ErrorCategory.RATE_LIMIT

        if isinstance(error, ToolExecutionError):
            return ErrorCategory.TOOL

        if isinstance(error, ModelExecutionError):
            return ErrorCategory.LLM

        if isinstance(error, ValidationError):
            return ErrorCategory.VALIDATION

        if isinstance(error, ContextCompressionError):
            return ErrorCategory.EXECUTION

        if isinstance(error, NetworkError):
            return ErrorCategory.NETWORK

        if isinstance(error, InternalAgentError):
            return ErrorCategory.INTERNAL

        if isinstance(error, (TimeoutError, ConnectionError)):
            return ErrorCategory.NETWORK

        if isinstance(error, ValueError):
            return ErrorCategory.VALIDATION

        return ErrorCategory.UNKNOWN

    def _get_severity(
        self,
        error: Exception,
    ) -> ErrorSeverity:

        if isinstance(
            error,
            InternalAgentError,
        ):
            return ErrorSeverity.CRITICAL

        if isinstance(
            error,
            (
                AuthenticationError,
                AuthorizationError,
            ),
        ):
            return ErrorSeverity.HIGH

        if isinstance(
            error,
            (
                RateLimitError,
                NetworkError,
                TimeoutError,
                ConnectionError,
            ),
        ):
            return ErrorSeverity.MEDIUM

        if isinstance(
            error,
            ValidationError,
        ):
            return ErrorSeverity.LOW

        return ErrorSeverity.MEDIUM

    def _is_retryable(
        self,
        error: Exception,
    ) -> bool:

        if isinstance(
            error,
            AgentRuntimeError,
        ):
            return error.retryable

        if isinstance(
            error,
            (
                TimeoutError,
                ConnectionError,
            ),
        ):
            return True

        return False

    def _is_recoverable(
        self,
        error: Exception,
    ) -> bool:

        if isinstance(
            error,
            ContextCompressionError,
        ):
            return error.recoverable

        if isinstance(
            error,
            (
                ValidationError,
                ToolExecutionError,
                ModelExecutionError,
                RateLimitError,
                NetworkError,
                TimeoutError,
                ConnectionError,
            ),
        ):
            return True

        return False
    