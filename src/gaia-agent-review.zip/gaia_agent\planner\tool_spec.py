from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ToolSpec:
    """
    Description of a tool exposed to the planner.

    ToolSpec does not execute the tool.

    It only describes:
    - tool name
    - tool description
    - argument schema
    """

    name: str
    description: str
    arguments_schema: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.name, str):
            raise TypeError(
                "Tool name must be a string."
            )

        if not self.name.strip():
            raise ValueError(
                "Tool name cannot be empty."
            )

        if not isinstance(self.description, str):
            raise TypeError(
                "Tool description must be a string."
            )

        if not self.description.strip():
            raise ValueError(
                "Tool description cannot be empty."
            )

        if self.arguments_schema is not None:
            if not isinstance(
                self.arguments_schema,
                dict,
            ):
                raise TypeError(
                    "arguments_schema must be a dictionary "
                    "or None."
                )