from __future__ import annotations

import json
from typing import Any, Sequence

from gaia_agent.llm.client import LLMClient
from gaia_agent.llm.model import LLMModel
from gaia_agent.reliability.errors import AgentError

from .plan_schema import PlanSchema, PlanStep, StepType
from .tool_spec import ToolSpec


class Planner:
    """
    Generates executable plans using the LLM.

    The planner does NOT execute tools.

    It only decides:
    - whether a step requires a tool
    - which registered tool should be used
    - what arguments should be supplied
    - whether an LLM step is sufficient
    """

    def __init__(
        self,
        client: LLMClient,
        model: LLMModel,
        available_tools: Sequence[ToolSpec] | None = None,
    ) -> None:

        self.client = client
        self.model = model

        self.available_tools = {
            tool.name: tool
            for tool in (available_tools or [])
        }

    async def generate_plan(
        self,
        user_question: str,
        context: Sequence[Any] | None = None,
    ) -> PlanSchema:

        if not user_question.strip():
            raise ValueError(
                "user_question cannot be empty."
            )

        prompt = self._build_plan_prompt(
            user_question=user_question,
            context=context or [],
        )

        plan = await self.client.generate(
            [
                {
                    "role": "system",
                    "content": self._system_prompt(),
                },
                {
                    "role": "user",
                    "content": prompt,
                },
            ],
            model=self.model,
            output_schema=PlanSchema,
        )

        if not isinstance(plan, PlanSchema):
            raise TypeError(
                "LLM returned an unexpected plan type."
            )

        self._validate_plan(plan)

        return plan

    async def replan_step(
        self,
        user_question: str,
        context: Sequence[Any] | None,
        failed_step: PlanStep,
        failure: AgentError,
    ) -> PlanStep:

        if not user_question.strip():
            raise ValueError(
                "user_question cannot be empty."
            )

        self._validate_step(failed_step)

        prompt = self._build_replan_step_prompt(
            user_question=user_question,
            context=context or [],
            failed_step=failed_step,
            failure=failure,
        )

        step = await self.client.generate(
            [
                {
                    "role": "system",
                    "content": self._replan_step_system_prompt(),
                },
                {
                    "role": "user",
                    "content": prompt,
                },
            ],
            model=self.model,
            output_schema=PlanStep,
        )

        if not isinstance(step, PlanStep):
            raise TypeError(
                "LLM returned an unexpected "
                "replan step type."
            )

        self._validate_step(step)

        return step

    def _validate_plan(
        self,
        plan: PlanSchema,
    ) -> None:

        if not plan.steps:
            raise ValueError(
                "Plan must contain at least one step."
            )

        for expected_id, step in enumerate(
            plan.steps
        ):

            if step.step_id != expected_id:
                raise ValueError(
                    "Plan step IDs must be sequential "
                    "starting from 0."
                )

            self._validate_step(step)

    def _validate_step(
        self,
        step: PlanStep,
    ) -> None:

        if not step.action.strip():
            raise ValueError(
                f"Step {step.step_id} "
                "has an empty action."
            )

        if step.step_type == StepType.TOOL:

            self._validate_tool_step(step)

        elif step.step_type == StepType.LLM:

            self._validate_llm_step(step)

        else:

            raise ValueError(
                f"Unsupported step type: "
                f"{step.step_type}"
            )

    def _validate_tool_step(
        self,
        step: PlanStep,
    ) -> None:

        if not step.tool_name:
            raise ValueError(
                f"Tool step {step.step_id} "
                "must specify tool_name."
            )

        if not self.available_tools:
            raise ValueError(
                "Plan contains a TOOL step, "
                "but no available tools were registered."
            )

        if step.tool_name not in self.available_tools:
            raise ValueError(
                f"Unknown tool "
                f"'{step.tool_name}' "
                f"in step {step.step_id}."
            )

        tool_spec = self.available_tools[
            step.tool_name
        ]

        self._validate_tool_arguments(
            step,
            tool_spec,
        )

    @staticmethod
    def _validate_llm_step(
        step: PlanStep,
    ) -> None:

        if step.tool_name is not None:
            raise ValueError(
                f"LLM step {step.step_id} "
                "must not specify tool_name."
            )

    @staticmethod
    def _validate_tool_arguments(
        step: PlanStep,
        tool_spec: ToolSpec,
    ) -> None:

        schema = tool_spec.arguments_schema

        if not schema:
            return

        if not isinstance(schema, dict):
            return

        required = schema.get(
            "required",
            [],
        )

        properties = schema.get(
            "properties",
            schema,
        )

        if not isinstance(
            properties,
            dict,
        ):
            return

        if not isinstance(
            required,
            list,
        ):
            required = []

        for argument_name in required:

            if argument_name not in step.arguments:
                raise ValueError(
                    f"Tool step {step.step_id} "
                    f"is missing required argument "
                    f"'{argument_name}'."
                )

    def _system_prompt(self) -> str:

        tools = self._format_tools()

        return f"""
You are the planning component of an AI agent.

Your task is to transform a user request into
a minimal executable plan.

Each step MUST be exactly one of:

- TOOL
- LLM

AVAILABLE TOOLS:

{tools}

STRICT OUTPUT RULES:

1. Return only data matching PlanSchema.
2. The first step MUST have step_id = 0.
3. Step IDs MUST be sequential:
   0, 1, 2, ...
4. Never invent a tool.
5. Use a TOOL step only when an available
   tool is actually required.
6. Every TOOL step MUST specify an exact
   available tool_name.
7. Every TOOL step MUST provide arguments
   appropriate for that tool.
8. Every LLM step MUST have tool_name = null.
9. Never use "None" as a tool_name.
10. Never use "null" as a string.
11. For LLM steps use:
    "tool_name": null
12. Keep the plan minimal.
13. Do not create unnecessary steps.
14. Steps must be ordered logically.
15. Every step must describe exactly
    one concrete operation.
16. Do not execute anything.

If the user request can be answered directly
without external information or tool usage,
create exactly one LLM step.

Example direct LLM step:

{{
  "step_id": 0,
  "action": "Answer the user's question",
  "step_type": "llm",
  "tool_name": null,
  "arguments": {{}},
  "is_final_answer": true
}}

Example TOOL step:

{{
  "step_id": 0,
  "action": "Search for the requested information",
  "step_type": "tool",
  "tool_name": "web_search",
  "arguments": {{
    "query": "..."
  }},
  "is_final_answer": false
}}
"""

    def _replan_step_system_prompt(
        self,
    ) -> str:

        tools = self._format_tools()

        return f"""
You are the recovery planning component
of an AI agent.

Your task is to replace ONE failed execution step.

AVAILABLE TOOLS:

{tools}

STRICT OUTPUT RULES:

1. Return exactly ONE PlanStep.
2. Never return a complete plan.
3. Never return multiple steps.
4. The replacement step_id MUST be 0.
5. Analyze the failure before choosing
   the replacement.
6. Do not blindly repeat the failed operation.
7. Change the strategy when the failure
   requires it.
8. Preserve useful information from
   the failed step.
9. Use only available tools.
10. TOOL steps MUST specify an available
    tool_name.
11. TOOL arguments must match the tool.
12. LLM steps MUST use:
    "tool_name": null
13. Never write "None" as tool_name.
14. Never write "null" as a string.
15. The replacement must be one concrete
    operation.
16. Do not execute the replacement.
17. Return only data matching PlanStep.

Example LLM replacement:

{{
  "step_id": 0,
  "action": "Answer using the available context",
  "step_type": "llm",
  "tool_name": null,
  "arguments": {{}},
  "is_final_answer": true
}}
"""

    def _build_plan_prompt(
        self,
        user_question: str,
        context: Sequence[Any],
    ) -> str:

        return f"""
Create an execution plan for this request.

USER REQUEST:

{user_question}

CURRENT CONTEXT:

{self._serialize_context(context)}

AVAILABLE TOOLS:

{self._format_tools()}

Determine the smallest sequence of steps
required to satisfy the user's request.

If the request can be answered directly by
the LLM without using a tool, create exactly
one LLM step.

For a direct LLM answer:

{{
  "step_id": 0,
  "action": "Answer the user's question",
  "step_type": "llm",
  "tool_name": null,
  "arguments": {{}},
  "is_final_answer": true
}}

For a tool operation, use the exact tool name
and provide the required arguments.
"""

    def _build_replan_step_prompt(
        self,
        user_question: str,
        context: Sequence[Any],
        failed_step: PlanStep,
        failure: AgentError,
    ) -> str:

        failed_step_json = failed_step.model_dump_json(
            indent=2
        )

        failure_json = self._serialize_failure(
            failure
        )

        return f"""
Create ONE replacement execution step
for a failed step.

USER REQUEST:

{user_question}

CURRENT CONTEXT:

{self._serialize_context(context)}

FAILED STEP:

{failed_step_json}

FAILURE:

{failure_json}

The previous step failed.

Determine the best alternative operation
that can continue solving the user's request.

The replacement must be ONE step only.

The replacement step_id MUST be 0.

If the replacement is an LLM step,
tool_name MUST be null.

Do not use the string "None".
Do not use the string "null".

Do not return a complete plan.
Do not return multiple steps.

Return exactly ONE replacement PlanStep.
"""

    def _format_tools(self) -> str:

        if not self.available_tools:
            return "No tools are currently available."

        lines: list[str] = []

        for tool in self.available_tools.values():

            arguments_schema = json.dumps(
                tool.arguments_schema or {},
                ensure_ascii=False,
            )

            lines.append(
                f"- {tool.name}\n"
                f"  Description: {tool.description}\n"
                f"  Arguments schema: {arguments_schema}"
            )

        return "\n".join(lines)

    @staticmethod
    def _serialize_context(
        context: Sequence[Any],
    ) -> str:

        if not context:
            return "No context available."

        try:

            return json.dumps(
                list(context),
                ensure_ascii=False,
                default=str,
                indent=2,
            )

        except (TypeError, ValueError):

            return str(list(context))

    @staticmethod
    def _serialize_failure(
        failure: AgentError,
    ) -> str:

        return json.dumps(
            {
                "error_type": failure.error_type,
                "message": failure.message,
                "category": failure.category.value,
                "severity": failure.severity.value,
                "retryable": failure.retryable,
                "recoverable": failure.recoverable,
                "source": failure.source,
                "operation": failure.operation,
                "attempt": failure.attempt,
                "details": failure.details,
            },
            ensure_ascii=False,
            indent=2,
            default=str,
        )