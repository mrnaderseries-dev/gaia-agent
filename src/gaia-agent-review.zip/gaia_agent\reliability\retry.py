from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Awaitable, Callable, Generic, TypeVar

from gaia_agent.reliability.errors import AgentError


T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class RetryResult(Generic[T]):
    success: bool
    result: T | None = None
    attempts: int = 0
    error: AgentError | None = None


class Retry:

    async def execute(
        self,
        operation: Callable[[], Awaitable[T]],
        *,
        max_attempts: int,
        delay: float = 2.0,
    ) -> RetryResult[T]:

        if max_attempts <= 0:
            raise ValueError(
                "max_attempts must be greater than 0."
            )

        if delay < 0:
            raise ValueError(
                "delay cannot be negative."
            )

        attempts = 0
        last_error: AgentError | None = None

        while attempts < max_attempts:

            attempts += 1

            try:

                result = await operation()

                return RetryResult(
                    success=True,
                    result=result,
                    attempts=attempts,
                )

            except AgentError as error:

                last_error = error

            except Exception as exc:

                last_error = AgentError(
                    error_type=type(exc).__name__,
                    message=str(exc),
                    source="retry",
                    operation="operation",
                    original_exception=exc,
                )

            if attempts < max_attempts and delay > 0:
                await asyncio.sleep(delay)

        return RetryResult(
            success=False,
            attempts=attempts,
            error=last_error,
        )