from __future__ import annotations

from pathlib import Path

from smolagents import Tool


class ListFilesTool(Tool):
    name = "list_files"

    description = (
        "List files and directories inside a directory "
        "relative to the allowed base directory."
    )

    inputs = {
        "directory": {
            "type": "string",
            "description": (
                "Directory relative to the allowed "
                "base directory."
            ),
            "nullable": True,
        },
    }

    output_type = "string"

    def __init__(
        self,
        base_dir: str = ".",
    ) -> None:
        super().__init__()
        self.base_dir = Path(base_dir).resolve()

    def forward(
        self,
        directory: str = ".",
    ) -> str:

        try:
            path = (
                self.base_dir / directory
            ).resolve()

            if not path.is_relative_to(
                self.base_dir
            ):
                return (
                    "Access outside the allowed "
                    "directory is not permitted."
                )

            if not path.exists():
                return (
                    f"Directory not found: {directory}"
                )

            if not path.is_dir():
                return (
                    f"Not a directory: {directory}"
                )

            entries = sorted(
                entry.name
                for entry in path.iterdir()
            )

            if not entries:
                return "Directory is empty."

            return "\n".join(entries)

        except Exception as exc:
            return (
                f"Error listing files: {exc}"
            )


class FileExistsTool(Tool):
    name = "file_exists"

    description = (
        "Check whether a file exists relative to "
        "the allowed base directory."
    )

    inputs = {
        "file_path": {
            "type": "string",
            "description": (
                "File path relative to the allowed "
                "base directory."
            ),
        },
    }

    output_type = "string"

    def __init__(
        self,
        base_dir: str = ".",
    ) -> None:
        super().__init__()
        self.base_dir = Path(base_dir).resolve()

    def forward(
        self,
        file_path: str,
    ) -> str:

        try:
            path = (
                self.base_dir / file_path
            ).resolve()

            if not path.is_relative_to(
                self.base_dir
            ):
                return (
                    "Access outside the allowed "
                    "directory is not permitted."
                )

            return (
                "True"
                if path.is_file()
                else "False"
            )

        except Exception as exc:
            return (
                f"Error checking file: {exc}"
            )


class ReadFileTool(Tool):
    name = "read_file"

    description = (
        "Read a UTF-8 text file relative to "
        "the allowed base directory."
    )

    inputs = {
        "file_path": {
            "type": "string",
            "description": (
                "File path relative to the allowed "
                "base directory."
            ),
        },
    }

    output_type = "string"

    def __init__(
        self,
        base_dir: str = ".",
    ) -> None:
        super().__init__()
        self.base_dir = Path(base_dir).resolve()

    def forward(
        self,
        file_path: str,
    ) -> str:

        try:
            path = (
                self.base_dir / file_path
            ).resolve()

            if not path.is_relative_to(
                self.base_dir
            ):
                return (
                    "Access outside the allowed "
                    "directory is not permitted."
                )

            if not path.exists():
                return (
                    f"File not found: {file_path}"
                )

            if not path.is_file():
                return (
                    f"Not a file: {file_path}"
                )

            return path.read_text(
                encoding="utf-8"
            )

        except UnicodeDecodeError:
            return (
                "This file is not a UTF-8 text file."
            )

        except Exception as exc:
            return (
                f"Error reading file: {exc}"
            )


class WriteFileTool(Tool):
    name = "write_file"

    description = (
        "Write UTF-8 text content to a file "
        "relative to the allowed base directory."
    )

    inputs = {
        "file_path": {
            "type": "string",
            "description": (
                "File path relative to the allowed "
                "base directory."
            ),
        },
        "content": {
            "type": "string",
            "description": (
                "Text content that should be written "
                "to the file."
            ),
        },
    }

    output_type = "string"

    def __init__(
        self,
        base_dir: str = ".",
    ) -> None:
        super().__init__()
        self.base_dir = Path(base_dir).resolve()

    def forward(
        self,
        file_path: str,
        content: str,
    ) -> str:

        try:
            path = (
                self.base_dir / file_path
            ).resolve()

            if not path.is_relative_to(
                self.base_dir
            ):
                return (
                    "Access outside the allowed "
                    "directory is not permitted."
                )

            path.parent.mkdir(
                parents=True,
                exist_ok=True,
            )

            path.write_text(
                content,
                encoding="utf-8",
            )

            return (
                "File written successfully: "
                f"{file_path}"
            )

        except Exception as exc:
            return (
                f"Error writing file: {exc}"
            )


class FileTools:
    """
    File-system tools used by the GAIA agent.

    Provides:
    - list_files
    - file_exists
    - read_file
    - write_file
    """

    def __init__(
        self,
        base_dir: str = ".",
    ) -> None:
        self.base_dir = Path(base_dir).resolve()

    def get_tools(self) -> list[Tool]:
        """
        Return all file tools for the central tool registry.
        """

        return [
            ListFilesTool(
                base_dir=str(self.base_dir),
            ),
            FileExistsTool(
                base_dir=str(self.base_dir),
            ),
            ReadFileTool(
                base_dir=str(self.base_dir),
            ),
            WriteFileTool(
                base_dir=str(self.base_dir),
            ),
        ]