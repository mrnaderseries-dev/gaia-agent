from __future__ import annotations

from pathlib import Path
from typing import Any

from smolagents import Tool


class AnalyzeImageTool(Tool):
    name = "analyze_image"

    description = (
        "Analyze an image and answer a question about "
        "the visual information contained in the image."
    )

    inputs = {
        "image_path": {
            "type": "string",
            "description": (
                "Path to the image relative to "
                "the allowed base directory."
            ),
        },
        "question": {
            "type": "string",
            "description": (
                "Question that should be answered "
                "using the image."
            ),
        },
    }

    output_type = "string"

    def __init__(
        self,
        model: Any,
        base_dir: str = ".",
    ) -> None:
        super().__init__()

        self.model = model
        self.base_dir = Path(base_dir).resolve()

    def forward(
        self,
        image_path: str,
        question: str,
    ) -> str:

        try:
            path = (
                self.base_dir / image_path
            ).resolve()

            if not path.is_relative_to(
                self.base_dir
            ):
                return (
                    "Access outside the allowed "
                    "directory is not permitted."
                )

            if not path.exists():
                return (
                    f"Image not found: {image_path}"
                )

            if not path.is_file():
                return (
                    f"Not a file: {image_path}"
                )

            valid_extensions = {
                ".jpg",
                ".jpeg",
                ".png",
                ".webp",
                ".bmp",
                ".gif",
            }

            if path.suffix.lower() not in valid_extensions:
                return (
                    "Unsupported image format: "
                    f"{path.suffix}"
                )

            if self.model is None:
                return (
                    "Vision model is not configured."
                )

            prompt = (
                "Analyze the provided image carefully.\n\n"
                f"Question: {question}\n\n"
                "Give a precise answer based only on "
                "the visual information available "
                "in the image."
            )

            response = self.model.generate(
                prompt=prompt,
                image=str(path),
            )

            return str(response)

        except Exception as exc:
            return (
                f"Error analyzing image: {exc}"
            )


class VisionTools:
    """
    Vision tools for the GAIA agent.
    """

    def __init__(
        self,
        model: Any,
        base_dir: str = ".",
    ) -> None:
        self.model = model
        self.base_dir = Path(base_dir).resolve()

    def get_tools(self) -> list[Tool]:
        """
        Create and return all vision tools.
        """

        return [
            AnalyzeImageTool(
                model=self.model,
                base_dir=str(self.base_dir),
            )
        ]