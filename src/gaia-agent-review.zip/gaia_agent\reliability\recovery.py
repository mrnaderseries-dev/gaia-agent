from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from gaia_agent.reliability.errors import AgentError


@dataclass(frozen=True, slots=True)
class RecoveryResult:
    recovered: bool
    result: Any | None = None
    error: AgentError | None = None
    reason: str = ""


class Recovery:

    async def execute(
        self,
        *,
        error: AgentError,
        operation: Callable[[], Awaitable[Any]],
    ) -> RecoveryResult:

        try:

            result = await operation()

            return RecoveryResult(
                recovered=True,
                result=result,
                reason="Recovery succeeded.",
            )

        except AgentError as recovery_error:

            return RecoveryResult(
                recovered=False,
                error=recovery_error,
                reason=recovery_error.message,
            )

        except Exception as exc:

            recovery_error = AgentError(
                error_type=type(exc).__name__,
                message=str(exc),
                source="recovery",
                operation="recovery",
                recoverable=False,
                original_exception=exc,
            )

            return RecoveryResult(
                recovered=False,
                error=recovery_error,
                reason=str(exc),
            )
        