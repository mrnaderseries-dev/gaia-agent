from __future__ import annotations

from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from smolagents import Tool


class AnalyzeExcelTool(Tool):
    name = "analyze_excel"

    description = (
        "Analyze an Excel workbook according to a user's question. "
        "The workbook data is extracted and passed to the configured "
        "language model for analysis."
    )

    inputs = {
        "file_path": {
            "type": "string",
            "description": (
                "Path to the Excel file relative to "
                "the allowed base directory."
            ),
        },
        "question": {
            "type": "string",
            "description": (
                "Question that should be answered using "
                "the Excel spreadsheet."
            ),
        },
    }

    output_type = "string"

    def __init__(
        self,
        model: Any = None,
        base_dir: str = ".",
    ) -> None:
        super().__init__()

        self.model = model
        self.base_dir = Path(base_dir).resolve()

    def _read_excel(
        self,
        path: Path,
    ) -> str:

        workbook = load_workbook(
            filename=path,
            data_only=True,
            read_only=True,
        )

        try:
            output: list[str] = []

            for sheet in workbook.worksheets:

                output.append(
                    f"Sheet: {sheet.title}"
                )

                for row in sheet.iter_rows(
                    values_only=True
                ):

                    values = [
                        ""
                        if value is None
                        else str(value)
                        for value in row
                    ]

                    output.append(
                        " | ".join(values)
                    )

                output.append("")

            return "\n".join(output)

        finally:
            workbook.close()

    def forward(
        self,
        file_path: str,
        question: str,
    ) -> str:

        try:
            path = (
                self.base_dir / file_path
            ).resolve()

            if not path.is_relative_to(
                self.base_dir
            ):
                return (
                    "Unsafe path: access outside "
                    "base directory."
                )

            if not path.exists():
                return (
                    f"File not found: {file_path}"
                )

            if not path.is_file():
                return (
                    f"Not a file: {file_path}"
                )

            valid_extensions = {
                ".xlsx",
                ".xlsm",
            }

            if path.suffix.lower() not in valid_extensions:
                return (
                    "Unsupported Excel format: "
                    f"{path.suffix}"
                )

            excel_data = self._read_excel(path)

            if self.model is None:
                return (
                    "LLM model is not configured."
                )

            prompt = f"""
You are analyzing an Excel spreadsheet.

User question:
{question}

Excel data:
{excel_data}

Instructions:
- Answer the user's question using the spreadsheet data.
- Do not invent information.
- If the spreadsheet does not contain enough information,
  say that the required information is unavailable.
- Return only the requested answer.
"""

            answer = self.model.generate(prompt)

            return str(answer)

        except Exception as exc:
            return (
                f"Excel analysis error: {exc}"
            )


class ExcelTools:
    """
    Excel tools for the GAIA agent.
    """

    def __init__(
        self,
        model: Any = None,
        base_dir: str = ".",
    ) -> None:
        self.model = model
        self.base_dir = Path(base_dir).resolve()

    def get_tools(self) -> list[Tool]:
        """
        Create and return all Excel tools.
        """

        return [
            AnalyzeExcelTool(
                model=self.model,
                base_dir=str(self.base_dir),
            )
        ]