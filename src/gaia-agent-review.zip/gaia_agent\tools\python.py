from smolagents import PythonInterpreterTool


class PythonTools:
    """
    Python execution tools used by the GAIA agent.

    Provides:
    - Python code execution
    - Access to the execution result
    """

    def __init__(self):
        self.python = PythonInterpreterTool()

    def get_tools(self) -> list:
        """
        Return all Python tools so they can be
        registered in the central tool registry.
        """
        return [
            self.python,
        ]