from __future__ import annotations

from pathlib import Path
from typing import Any

from smolagents import Tool


class AudioAnalysisTool(Tool):
    name = "audio_analysis"

    description = (
        "Analyze an audio file according to a user's question. "
        "The tool transcribes the audio and then uses the configured "
        "language model to answer the question from the transcript."
    )

    inputs = {
        "file_path": {
            "type": "string",
            "description": (
                "Path to the audio file relative to the allowed "
                "base directory."
            ),
        },
        "question": {
            "type": "string",
            "description": (
                "Question that should be answered using the audio."
            ),
        },
    }

    output_type = "string"

    def __init__(
        self,
        stt_backend: Any,
        base_dir: str = ".",
        model: Any = None,
    ) -> None:
        super().__init__()

        self.stt_backend = stt_backend
        self.base_dir = Path(base_dir).resolve()
        self.model = model

    def forward(
        self,
        file_path: str,
        question: str,
    ) -> str:

        try:
            path = (
                self.base_dir / file_path
            ).resolve()

            if not path.is_relative_to(self.base_dir):
                return (
                    "Unsafe path: access outside "
                    "base directory."
                )

            if not path.exists():
                return (
                    f"File not found: {file_path}"
                )

            if not path.is_file():
                return (
                    f"Not a file: {file_path}"
                )

            valid_extensions = {
                ".mp3",
                ".wav",
                ".m4a",
                ".flac",
                ".ogg",
            }

            if path.suffix.lower() not in valid_extensions:
                return (
                    "Unsupported audio format: "
                    f"{path.suffix}"
                )

            if self.stt_backend is None:
                return (
                    "Audio transcription backend "
                    "is not configured."
                )

            if self.model is None:
                return (
                    "LLM model is not configured."
                )

            audio_text = self.stt_backend.transcribe(
                str(path)
            )

            prompt = f"""
You are analyzing an audio transcript.

User question:
{question}

Audio transcript:
{audio_text}

Instructions:
- Answer the user's question using only
  information available in the transcript.
- If the transcript is unclear or insufficient,
  return exactly:
  audio text not good
- Return only the requested information.
"""

            answer = self.model.generate(prompt)

            return str(answer)

        except Exception as exc:
            return (
                f"Audio analysis error: {exc}"
            )


class AudioTools:
    """
    Audio tools used by the GAIA agent.
    """

    def __init__(
        self,
        stt_backend: Any,
        base_dir: str = ".",
        model: Any = None,
    ) -> None:
        self.stt_backend = stt_backend
        self.base_dir = Path(base_dir).resolve()
        self.model = model

    def get_tools(self) -> list[Tool]:
        """
        Create and return all audio tools.
        """

        return [
            AudioAnalysisTool(
                stt_backend=self.stt_backend,
                base_dir=str(self.base_dir),
                model=self.model,
            )
        ]